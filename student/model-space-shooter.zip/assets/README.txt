Many thanks to the following parties.  

All materials licensed under CC0 unless otherwise specified.

Software: 
  
Audacity (http://audacityteam.org/) 
Audio Tool (https://www.audiotool.com/)
Construct 2 (Paid version) by Scirra (https://www.scirra.com/)
Kenney Studio (http://kenney.nl/projects/kenney-studio)
Inkscape (https://inkscape.org/en/)
ShoeBox (http://renderhjs.net/shoebox/)
        
Graphics:

Kenney (www.kenney.nl)
Donate: http://donate.kenney.nl/
Request: http://request.kenney.nl/

Fonts: 

Kenney Future

Audio:

Game sounds from Kenney asset packs and Construct 2 examples
Game theme "Space Seagulls" created by James Colestock using Audio Tool